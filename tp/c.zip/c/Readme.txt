使用方法：
gcc编译：
gcc -o Test_OS Test_OS.sh.x.c

clang编译:
clang -o Test_OS Test_OS.sh.x.c

新搞了点功能，自己找